class testmain:
    def test_go_up(self):
        assert False
